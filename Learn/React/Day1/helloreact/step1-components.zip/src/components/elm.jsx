import NestedElm from "./nestedelm"

let Elm = function(){

    let messages = [1, 2, 3, 4, 5]
    /* return <ul>
                <NestedElm message = "Item 1"/>
                <NestedElm message = "Item 2"/>
                <NestedElm message = "Item 3"/>
                <NestedElm message = "Item 4"/>
           </ul> */
           return   <ul>
                        {messages.map((val, idx)=><NestedElm key = {idx} messages = {val}/>)}
                    </ul>
}

export default Elm;