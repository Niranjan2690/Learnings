
let NestedElm = function(props){
    //let message = "Hello"
    return <li>  {props.messages || "deafult Message"}  </li>
}

export default NestedElm;