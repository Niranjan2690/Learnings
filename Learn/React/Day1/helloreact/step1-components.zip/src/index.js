import React from "react";
import ReactDOM from "react-dom/client";
import Elm from "./components/elm"


ReactDOM.createRoot(document.getElementById("root")).render(<Elm/>)
